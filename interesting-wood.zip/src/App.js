import React, { useState, useEffect, useRef } from "react";
import {
  Heart,
  Music,
  ArrowRight,
  Star,
  Moon,
  Volume2,
  VolumeX,
} from "lucide-react";

// --- Assets & Data Configuration --

const ASSETS = {
  chalJhuthi:
    "https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExOGYwcjNjMXdxeDl4d2tnMjZscWI0bDF4dnljMTBpejhzcnoyNGs5bCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/6vXxdi5g4HEOAhxLj8/giphy.gif",
  bikeRide: "https://i.ibb.co/S4F5WCN9/Amazing-Night.webp",
  carRefusal:
    "https://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExbXJhYWYwOGFleW1qMzZsM2g4YjBiMDQ5bWdiMWx6Z25qa3l6ZHJmdSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/mIMsLsQTJzAn6/giphy.gif",
  hug: "https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExeDc1Z2NtbjR1bTVtOGI1dHp6aG55cGJkbTc2MDBodjFraG00ejhmaCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/KG5oq4vesf9r8JbBEN/giphy.gif",
  noodles: "https://i.ibb.co/q3Lw46xT/Noodle-from-own-hand.webp",
  mouthBurn:
    "https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExZTN2Z3p5ZjQ0czM0dGJpbjdiYW9ldXBkeTZnb3VwcDExYnJvc3F0aiZlcD12MV9naWZzX3NlYXJjaCZjdD1n/kOF7S4sm981R5Z3zMh/giphy.gif",
  feedingHand: "https://i.ibb.co/kVDmf5SX/Noodle-from-hand.webp",
  feedingMouth: "https://i.ibb.co/jP8Y4pd9/Mouth-to-mouth-Noodle.webp",
  favFood:
    "https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExbWFleDRvNmhmODN2c3JnbXdnb2JxM2t0bmF1eXpqdnR5a2Q3NWNuciZlcD12MV9naWZzX3NlYXJjaCZjdD1n/Z2IoReHYnRxyU/giphy.gif",
  iceCream: "https://i.ibb.co/7JjFdhCq/Icecream.webp",
  sardi:
    "https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExYjFlZjBvbWJqNnNsa3I3aHc2amM5bXlzdjU0bTl6cnEzMXdxZTU5diZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/2lzhUOZsRY86Y/giphy.gif",
  jagjit:
    "https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExdWI1OHk4ZHlsc29mNnFqc3A0d3VrdDhnZnh3cWFpNTgyMXVxd2N1eCZlcD12MV9naWZzX3NlYXJjaCZjdD1n/SAIWAI0y1DldFgg2fz/giphy.gif",
  coupleNight: "https://i.ibb.co/2348m1Lz/Listening-Kishore-kumar.webp",
  pyal: "https://media.giphy.com/media/26BRv0ThflsHCqDrG/giphy.gif",
  gravity:
    "https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExNjVteWY4ZHp6dGtlYmw5dXQ2MHJremlvNTlvM29tN2YxZWV2NzhwayZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/l1J9z5SmyhtdybtaU/giphy.gif",
  kissForehead: "https://i.ibb.co/zVGXFj6K/Forhead.webp",
  leftkissEye: "https://i.ibb.co/Lzq4nH40/eye.webp",
  rightkissEye: "https://i.ibb.co/xKfG6L9x/Right-eye.jpg",
  leftkissCheek: "https://i.ibb.co/Rk2k9NHX/Cheek.webp",
  rightkissCheek: "https://i.ibb.co/DPNNBj2R/Right-cheek.jpg",
  kissNose: "https://i.ibb.co/C3mhtmDk/Nose.webp",
  kissLip: "https://i.ibb.co/ZRmKkWkR/Lip-lock.webp",
  kissNeck: "https://i.ibb.co/5gsfDv15/Neck.webp",
  kissShoulder: "https://i.ibb.co/99hLKThR/Shoulder.webp",
  melt: "https://i.ibb.co/4ggcLpC7/Melting.webp",
  finalHug: "https://i.ibb.co/Sw3LvBHZ/Tight-Hug.webp",
  coldNight: "https://i.ibb.co/2348m1Lz/Listening-Kishore-kumar.webp",
  onBack: "https://i.ibb.co/dwPKD6hv/On-Back.webp",
  jugnu: "https://i.ibb.co/5WrktC4g/Special-place.webp",
  birthdayBalloons:
    "https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExb3JuanF2d2piY2sxbzRrd256a3dycTZrNWttOGw5eDluczYxaXljNyZlcD12MV9naWZzX3NlYXJjaCZjdD1n/l4KhWPNyLHiB3TjVe/giphy.gif",
  birthdayCake: "https://i.ibb.co/nNf45vkz/Celebration.webp",
};

// Song: Aa Chalke Tujhe Main Leke Chalun - Kishore Kumar (Youtube ID)
const YOUTUBE_VIDEO_ID = "1s747Jd7tWQ";

// --- Components ---

const Modal = ({ isOpen, onClose, message, gif }) => {
  if (!isOpen) return null;
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 50,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "rgba(0,0,0,0.8)",
        backdropFilter: "blur(4px)",
        padding: "1rem",
      }}
    >
      <div
        style={{
          backgroundColor: "white",
          border: "2px solid #f9a8d4",
          borderRadius: "1.5rem",
          padding: "1.5rem",
          maxWidth: "24rem",
          width: "100%",
          textAlign: "center",
          boxShadow: "0 0 30px rgba(236,72,153,0.5)",
        }}
      >
        {gif && (
          <img
            src={gif}
            alt="Reaction"
            style={{
              width: "100%",
              height: "12rem",
              objectFit: "cover",
              borderRadius: "0.75rem",
              marginBottom: "1rem",
              border: "2px solid #fce7f3",
            }}
          />
        )}
        <p
          style={{
            fontSize: "1.25rem",
            color: "#1f2937",
            fontWeight: "bold",
            marginBottom: "1.5rem",
            fontFamily: "Nunito, sans-serif",
          }}
        >
          {message}
        </p>
        <button
          onClick={onClose}
          style={{
            background: "linear-gradient(to right, #ec4899, #f43f5e)",
            color: "white",
            padding: "0.75rem 2rem",
            borderRadius: "9999px",
            fontWeight: "bold",
            boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
            border: "none",
            cursor: "pointer",
          }}
        >
          Okay Ji 🙈
        </button>
      </div>
    </div>
  );
};

const BackgroundEffects = () => {
  const stars = Array.from({ length: 40 }).map((_, i) => ({
    id: `star-${i}`,
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    size: Math.random() * 3 + 1 + "px",
    animationDuration: `${Math.random() * 3 + 1}s`,
    animationDelay: `${Math.random() * 2}s`,
  }));

  const hearts = Array.from({ length: 15 }).map((_, i) => ({
    id: `heart-${i}`,
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100 + 20}%`,
    scale: Math.random() * 0.5 + 0.5,
    animationDuration: `${Math.random() * 15 + 10}s`,
    animationDelay: `${Math.random() * 5}s`,
  }));

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        pointerEvents: "none",
        zIndex: 0,
        overflow: "hidden",
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(circle at 50% 50%, rgba(76,29,149,0.2), rgba(15,23,42,0.4))",
        }}
      ></div>
      {stars.map((s) => (
        <div
          key={s.id}
          style={{
            position: "absolute",
            backgroundColor: "white",
            borderRadius: "9999px",
            opacity: 0.7,
            left: s.left,
            top: s.top,
            width: s.size,
            height: s.size,
            animation: `twinkle ${s.animationDuration} infinite ease-in-out ${s.animationDelay}`,
            boxShadow: "0 0 5px 1px rgba(255,255,255,0.6)",
          }}
        />
      ))}
      {hearts.map((h) => (
        <div
          key={h.id}
          style={{
            position: "absolute",
            color: "rgba(236,72,153,0.3)",
            left: h.left,
            top: h.top,
            transform: `scale(${h.scale})`,
            animation: `floatUp ${h.animationDuration} infinite linear ${h.animationDelay}`,
          }}
        >
          <Heart fill="currentColor" />
        </div>
      ))}
    </div>
  );
};

export default function App() {
  const [currentCard, setCurrentCard] = useState(1);
  const [modal, setModal] = useState({ show: false, message: "", gif: "" });
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [currentCard]);

  const triggerModal = (message, gif) => {
    setModal({ show: true, message, gif });
  };

  const closeModal = () => {
    setModal({ ...modal, show: false });
  };

  const nextCard = () => setCurrentCard((prev) => prev + 1);
  const goToCard = (cardNumber) => setCurrentCard(cardNumber);

  const toggleMusic = () => {
    setIsPlaying(!isPlaying);
  };

  const PrimaryButton = ({ onClick, children, style = {} }) => (
    <button
      onClick={onClick}
      style={{
        background: "linear-gradient(to right, #ec4899, #f43f5e, #db2777)",
        color: "white",
        fontWeight: "bold",
        padding: "0.75rem 1.5rem",
        borderRadius: "0.75rem",
        boxShadow: "0 4px 15px rgba(236,72,153,0.4)",
        border: "2px solid #f472b6",
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "0.5rem",
        cursor: "pointer",
        ...style,
      }}
    >
      {children}
    </button>
  );

  const OptionButton = ({ onClick, children, style = {} }) => (
    <button
      onClick={onClick}
      style={{
        backgroundColor: "rgba(255,255,255,0.1)",
        backdropFilter: "blur(4px)",
        color: "white",
        fontWeight: "bold",
        padding: "0.75rem 1.5rem",
        borderRadius: "0.75rem",
        border: "2px solid rgba(255,255,255,0.3)",
        boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "0.5rem",
        cursor: "pointer",
        ...style,
      }}
    >
      {children}
    </button>
  );

  const renderCardContent = () => {
    switch (currentCard) {
      case 1:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h1
              style={{
                fontSize: "clamp(1.875rem, 4vw, 2.25rem)",
                fontWeight: 800,
                background: "linear-gradient(to right, #fbcfe8, #e9d5ff)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              Moti! Itne Din se IOCL mein padi ho...
            </h1>
            <p style={{ fontSize: "1.25rem", color: "white", fontWeight: 600 }}>
              Aren't you feeling bored ? 🤔
            </p>
            <div
              style={{
                display: "flex",
                gap: "1rem",
                justifyContent: "center",
                marginTop: "2rem",
              }}
            >
              <OptionButton onClick={nextCard}>Yes 🥺</OptionButton>
              <OptionButton
                onClick={() =>
                  triggerModal("Chal Jhhuthhi!", ASSETS.chalJhuthi)
                }
              >
                No 😒
              </OptionButton>
            </div>
          </div>
        );

      case 2:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{ fontSize: "1.5rem", color: "white", fontWeight: "bold" }}
            >
              Then chal, Tumhe ghuma ke laata hu...
            </h2>
            <p
              style={{
                fontSize: "1.125rem",
                color: "#fbcfe8",
                fontWeight: 500,
              }}
            >
              Car se chalegi ya Bike se?
            </p>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "1rem",
                alignItems: "center",
                marginTop: "1rem",
              }}
            >
              <OptionButton onClick={nextCard}>Bike 🏍️</OptionButton>
              <OptionButton
                onClick={() =>
                  triggerModal(
                    "Nahi, I will not take you in the car, Car mein alag alag seat hoti hai 😉",
                    ASSETS.carRefusal
                  )
                }
              >
                Car 🚗
              </OptionButton>
            </div>
          </div>
        );

      case 3:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <img
              src={ASSETS.bikeRide}
              alt="Bike Ride"
              style={{
                borderRadius: "0.75rem",
                width: "100%",
                height: "12rem",
                objectFit: "cover",
                marginBottom: "1rem",
                border: "2px solid rgba(236,72,153,0.3)",
                boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
              }}
            />
            <p
              style={{
                fontSize: "1.125rem",
                color: "white",
                lineHeight: "1.625",
                fontWeight: 500,
              }}
            >
              "Kitni Suhani raat hai... Ho rahi tumse mithi-mithi baat hai, itni
              sunsaan raat mein, hum dono saath hain... Aisa lag raha hai
              sabkuch mil gaya hai, jab tumhara haath mere haath hai"
            </p>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "1rem",
                marginTop: "1.5rem",
              }}
            >
              <OptionButton
                onClick={() => triggerModal("Awww... *Tight Hug*", ASSETS.hug)}
              >
                I wish ye moment tham jaaye ✨
              </OptionButton>
              <OptionButton onClick={nextCard}>
                Ha, Haath me haath daal ke ab aage bhi badhte hain 😄
              </OptionButton>
            </div>
          </div>
        );

      case 4:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{ fontSize: "1.5rem", color: "white", fontWeight: "bold" }}
            >
              Yaar... Tumhe bhukh bhi lag gayi hogi na?
            </h2>
            <p style={{ color: "#fbcfe8", fontWeight: 500 }}>
              Chal Moti Chaumin khilata hu... 🍜
            </p>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "1rem",
                marginTop: "1.5rem",
              }}
            >
              <OptionButton onClick={nextCard}>
                Ha, Bahut Khane ka man kar raha hai 😋
              </OptionButton>
              <OptionButton
                onClick={() =>
                  triggerModal(
                    "Bakk, Muh jala logi, first aid bhi nahi hai... then I will have left only option to fix your burn.. 🙈",
                    ASSETS.mouthBurn
                  )
                }
              >
                Yeah, I can't wait, Jaldi- Jaldi 🏃‍♀️
              </OptionButton>
            </div>
          </div>
        );

      case 5:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{ fontSize: "1.5rem", color: "white", fontWeight: "bold" }}
            >
              Muhh Khol, apne haathon se khilata hu...
            </h2>
            <div style={{ marginTop: "2rem" }}>
              <PrimaryButton onClick={nextCard}>
                AAaaaaaaaa......... 😮
              </PrimaryButton>
            </div>
          </div>
        );

      case 6:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <img
              src={ASSETS.feedingHand}
              alt="Feeding"
              style={{
                borderRadius: "0.75rem",
                width: "100%",
                height: "16rem",
                objectFit: "cover",
                border: "2px solid rgba(236,72,153,0.3)",
              }}
            />
            <PrimaryButton onClick={nextCard}>
              Now, Don't use hand, haath se man bhar gaya, Feed Mouth to Mouth..
              😳
            </PrimaryButton>
          </div>
        );

      case 7:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <img
              src={ASSETS.feedingMouth}
              alt="Mouth feeding"
              style={{
                borderRadius: "0.75rem",
                width: "100%",
                height: "16rem",
                objectFit: "cover",
                border: "2px solid rgba(236,72,153,0.3)",
              }}
            />
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "1rem",
                justifyContent: "center",
                marginTop: "1.5rem",
              }}
            >
              <OptionButton
                onClick={() =>
                  triggerModal(
                    "Favourite chizon se kiska hi man bhara hai.... 😉",
                    ASSETS.favFood
                  )
                }
              >
                Yaar, Man nahi bhara...
              </OptionButton>
              <OptionButton onClick={nextCard}>
                Pet bhar gaya... 😌
              </OptionButton>
            </div>
          </div>
        );

      case 8:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{ fontSize: "1.5rem", color: "white", fontWeight: "bold" }}
            >
              Chal ab thoda Muh meetha karate hain...
            </h2>
            <p
              style={{
                fontSize: "1.125rem",
                color: "#fbcfe8",
                fontWeight: 500,
              }}
            >
              Rabdi wale ice cream se... 🍨 Kitne le lu?
            </p>
            <div
              style={{
                display: "flex",
                gap: "1rem",
                justifyContent: "center",
                marginTop: "1.5rem",
              }}
            >
              <OptionButton onClick={nextCard}>
                1 me hi dono kha lenge..😄
              </OptionButton>
              <OptionButton
                onClick={() =>
                  triggerModal(
                    "Nahi, tumhe sardi ho jaayegi 🤧...",
                    ASSETS.sardi
                  )
                }
              >
                Bahut saale.. 😈
              </OptionButton>
            </div>
          </div>
        );

      case 9:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <img
              src={ASSETS.iceCream}
              alt="Ice Cream"
              style={{
                borderRadius: "0.75rem",
                width: "100%",
                height: "16rem",
                objectFit: "cover",
                border: "2px solid rgba(236,72,153,0.3)",
              }}
            />
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "2rem",
              }}
            >
              <button
                onClick={nextCard}
                style={{
                  background: "#ec4899",
                  padding: "1rem",
                  borderRadius: "9999px",
                  color: "white",
                  boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                <ArrowRight size={32} />
              </button>
            </div>
          </div>
        );

      case 10:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{ fontSize: "1.5rem", color: "white", fontWeight: "bold" }}
            >
              Khane-Pine ka to ho gaya...
            </h2>
            <p style={{ color: "rgba(255,255,255,0.9)", fontWeight: 500 }}>
              Ab is suhani raat ka feel lete hain.... Ek Earbuds tu laga, aur ek
              main... Bolo Kinka song lagaun.. 🎧
            </p>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "1rem",
                justifyContent: "center",
                marginTop: "1.5rem",
              }}
            >
              <OptionButton
                onClick={() => {
                  if (!isPlaying) toggleMusic();
                  nextCard();
                }}
              >
                <Music size={20} /> Kishore Kumar
              </OptionButton>
              <OptionButton
                onClick={() =>
                  triggerModal(
                    "Kishor da ko hi sun lete hain..Inka Gazal rula degi.... ☺️",
                    ASSETS.jagjit
                  )
                }
              >
                Jagjit Singh
              </OptionButton>
            </div>
          </div>
        );

      case 11:
        return (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "1.5rem",
              textAlign: "center",
            }}
          >
            <div style={{ position: "relative" }}>
              <img
                src={ASSETS.coupleNight}
                alt="Romantic Night"
                style={{
                  borderRadius: "0.75rem",
                  width: "100%",
                  height: "16rem",
                  objectFit: "cover",
                  opacity: 0.8,
                  border: "2px solid rgba(255,255,255,0.2)",
                }}
              />
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <div
                  style={{
                    backgroundColor: "rgba(255,255,255,0.2)",
                    padding: "1rem",
                    borderRadius: "9999px",
                    backdropFilter: "blur(4px)",
                    border: "1px solid rgba(255,255,255,0.3)",
                    boxShadow: "0 0 20px rgba(255,255,255,0.3)",
                  }}
                >
                  <Music
                    style={{ color: "#f9a8d4", width: "3rem", height: "3rem" }}
                  />
                </div>
              </div>
            </div>
            <p
              style={{
                color: "#fbcfe8",
                fontWeight: "bold",
                fontSize: "1.25rem",
              }}
            >
              Playing: Aa Chalke Tujhe...
            </p>

            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "2rem",
              }}
            >
              <button
                onClick={nextCard}
                style={{
                  background: "#ec4899",
                  padding: "1rem",
                  borderRadius: "9999px",
                  color: "white",
                  boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                <ArrowRight size={32} />
              </button>
            </div>
          </div>
        );

      case 12:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{ fontSize: "1.5rem", color: "white", fontWeight: "bold" }}
            >
              Chal Moti tumhe kuch dikhata hu... ✨
            </h2>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "1rem",
                justifyContent: "center",
                marginTop: "1.5rem",
              }}
            >
              <OptionButton onClick={() => goToCard(13)}>
                Nahi, Mera pair thak gaya hai 🥺
              </OptionButton>
              <OptionButton
                onClick={() =>
                  triggerModal(
                    "Zyada der taalab ke kinare rukegi to thandh lag jayegi tumhe...",
                    ASSETS.coldNight
                  )
                }
              >
                Abhi, yahi ruko 🤗
              </OptionButton>
            </div>
          </div>
        );

      case 13:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{ fontSize: "1.5rem", color: "white", fontWeight: "bold" }}
            >
              Thik aa baitha leta hu tumhe apne picche....😄
            </h2>
            <img
              src={ASSETS.onBack}
              alt="On Back"
              style={{
                borderRadius: "0.75rem",
                width: "100%",
                height: "16rem",
                objectFit: "cover",
                border: "4px solid rgba(236,72,153,0.3)",
                boxShadow: "0 20px 25px -5px rgba(0,0,0,0.1)",
              }}
            />
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "2rem",
              }}
            >
              <button
                onClick={() => goToCard(14)}
                style={{
                  background: "#ec4899",
                  padding: "1rem",
                  borderRadius: "9999px",
                  color: "white",
                  boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                <ArrowRight size={32} />
              </button>
            </div>
          </div>
        );

      case 14:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{ fontSize: "1.5rem", color: "white", fontWeight: "bold" }}
            >
              Dekh kitne saare jugnu....✨
            </h2>
            <img
              src={ASSETS.jugnu}
              alt="Jugnu"
              style={{
                borderRadius: "0.75rem",
                width: "100%",
                height: "16rem",
                objectFit: "cover",
                border: "4px solid rgba(250,204,21,0.5)",
                boxShadow: "0 20px 25px -5px rgba(0,0,0,0.1)",
              }}
            />
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "2rem",
              }}
            >
              <button
                onClick={() => goToCard(15)}
                style={{
                  background: "#ec4899",
                  padding: "1rem",
                  borderRadius: "9999px",
                  color: "white",
                  boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                <ArrowRight size={32} />
              </button>
            </div>
          </div>
        );

      case 15:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{ fontSize: "1.875rem", fontWeight: 800, color: "white" }}
            >
              Trishuuu.....
            </h2>
            <p
              style={{ fontSize: "1.25rem", color: "#fbcfe8", fontWeight: 600 }}
            >
              Today is very special day na.. 🤗🤗
            </p>
            <div style={{ marginTop: "1.5rem" }}>
              <PrimaryButton onClick={nextCard}>Haa ji... ❤️</PrimaryButton>
            </div>
          </div>
        );

      case 16:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{ fontSize: "1.5rem", color: "white", fontWeight: "bold" }}
            >
              Ha to...
            </h2>
            <p
              style={{ fontSize: "1.125rem", color: "white", fontWeight: 500 }}
            >
              I wanna give something jo mere pass tumhare liye bahut saala
              hai..... 🙈
            </p>
            <div style={{ marginTop: "1.5rem" }}>
              <PrimaryButton onClick={nextCard}>
                Kya hai bahut saala.. 🤔
              </PrimaryButton>
            </div>
          </div>
        );

      case 17:
        return (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "1.5rem",
              alignItems: "center",
            }}
          >
            <h1
              style={{
                fontSize: "3rem",
                fontWeight: 800,
                background: "linear-gradient(to right, #fecaca, #ec4899)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
              }}
            >
              Pyaa.....................l 🙈
            </h1>
            <img
              src={ASSETS.pyal}
              style={{
                width: "14rem",
                height: "14rem",
                borderRadius: "9999px",
                border: "4px solid #f472b6",
                boxShadow: "0 0 30px rgba(236,72,153,0.6)",
                objectFit: "cover",
              }}
            />
            <div style={{ marginTop: "2rem" }}>
              <button
                onClick={nextCard}
                style={{
                  background: "#ec4899",
                  padding: "1rem",
                  borderRadius: "9999px",
                  color: "white",
                  boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                <ArrowRight size={32} />
              </button>
            </div>
          </div>
        );

      case 18:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{ fontSize: "1.5rem", color: "white", fontWeight: "bold" }}
            >
              To batao....
            </h2>
            <p
              style={{
                fontSize: "1.125rem",
                color: "#fbcfe8",
                fontWeight: 500,
              }}
            >
              How I should transfer to you..
            </p>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "1rem",
                marginTop: "1.5rem",
              }}
            >
              <OptionButton
                onClick={() =>
                  triggerModal(
                    "Nahi ji, Ye gravitational force ke against ho jaayega.... ☺️",
                    ASSETS.gravity
                  )
                }
              >
                Downward to Upward ⬆️
              </OptionButton>
              <OptionButton onClick={nextCard}>
                Upward to Downward ⬇️
              </OptionButton>
            </div>
          </div>
        );

      case 19:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{
                fontSize: "1.875rem",
                color: "white",
                fontWeight: "bold",
              }}
            >
              Accha, Ab paas aao...
            </h2>
            <p
              style={{ fontSize: "1.25rem", color: "#fbcfe8", fontWeight: 500 }}
            >
              Aur aankhe band karo.. 😌
            </p>
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "3rem",
              }}
            >
              <button
                onClick={nextCard}
                style={{
                  background: "#ec4899",
                  padding: "1rem",
                  borderRadius: "9999px",
                  color: "white",
                  boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                <ArrowRight size={32} />
              </button>
            </div>
          </div>
        );

      case 20:
        return (
          <KissCard
            title="Forehead 😘"
            gif={ASSETS.kissForehead}
            onNext={nextCard}
          />
        );
      case 21:
        return (
          <KissCard
            title="Left Eye 😘"
            gif={ASSETS.leftkissEye}
            onNext={nextCard}
          />
        );
      case 22:
        return (
          <KissCard
            title="Right Eye 😘"
            gif={ASSETS.rightkissEye}
            onNext={nextCard}
          />
        );
      case 23:
        return (
          <KissCard
            title="Left Cheek 😘"
            gif={ASSETS.leftkissCheek}
            onNext={nextCard}
          />
        );
      case 24:
        return (
          <KissCard
            title="Right Cheek 😘"
            gif={ASSETS.rightkissCheek}
            onNext={nextCard}
          />
        );
      case 25:
        return (
          <KissCard title="Nose 😘" gif={ASSETS.kissNose} onNext={nextCard} />
        );
      case 26:
        return (
          <KissCard
            title="Lip Lock 😘"
            gif={ASSETS.kissLip}
            onNext={nextCard}
          />
        );
      case 27:
        return (
          <KissCard title="Neck 😘" gif={ASSETS.kissNeck} onNext={nextCard} />
        );
      case 28:
        return (
          <KissCard
            title="Shoulder 😘"
            gif={ASSETS.kissShoulder}
            onNext={nextCard}
          />
        );

      case 29:
        return (
          <div
            style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}
          >
            <h2
              style={{ fontSize: "1.5rem", color: "white", fontWeight: "bold" }}
            >
              Ab zyda downward nahi jaaunga...
            </h2>
            <p
              style={{ fontSize: "1.25rem", color: "#fbcfe8", fontWeight: 500 }}
            >
              Tu melt ho jaayegi..... 😄
            </p>
            <img
              src={ASSETS.melt}
              style={{
                width: "100%",
                height: "12rem",
                objectFit: "cover",
                borderRadius: "0.75rem",
                opacity: 0.9,
                border: "1px solid #f472b6",
              }}
            />
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "2rem",
              }}
            >
              <button
                onClick={nextCard}
                style={{
                  background: "#ec4899",
                  padding: "1rem",
                  borderRadius: "9999px",
                  color: "white",
                  boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                <ArrowRight size={32} />
              </button>
            </div>
          </div>
        );

      case 30:
        return (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "1rem",
              textAlign: "center",
              background:
                "linear-gradient(to bottom, rgba(88,28,135,0.8), rgba(131,24,67,0.8), rgba(136,19,55,0.8))",
              backdropFilter: "blur(4px)",
              padding: "1.5rem",
              borderRadius: "1rem",
              maxHeight: "60vh",
              overflowY: "auto",
              border: "2px solid rgba(250,204,21,0.5)",
              boxShadow: "0 0 50px rgba(255,215,0,0.3)",
              position: "relative",
            }}
          >
            <div
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                pointerEvents: "none",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  position: "absolute",
                  top: "0.5rem",
                  left: "0.5rem",
                  fontSize: "2.25rem",
                }}
              >
                🎈
              </div>
              <div
                style={{
                  position: "absolute",
                  top: "0.5rem",
                  right: "0.5rem",
                  fontSize: "2.25rem",
                }}
              >
                🎉
              </div>
              <div
                style={{
                  position: "absolute",
                  bottom: "0.5rem",
                  left: "0.5rem",
                  fontSize: "2.25rem",
                }}
              >
                🎂
              </div>
              <div
                style={{
                  position: "absolute",
                  bottom: "0.5rem",
                  right: "0.5rem",
                  fontSize: "2.25rem",
                }}
              >
                🎊
              </div>
              <div
                style={{
                  position: "absolute",
                  top: "50%",
                  left: 0,
                  fontSize: "1.875rem",
                }}
              >
                ✨
              </div>
              <div
                style={{
                  position: "absolute",
                  top: "50%",
                  right: 0,
                  fontSize: "1.875rem",
                }}
              >
                ✨
              </div>
            </div>

            <div style={{ position: "relative", marginBottom: "1.5rem" }}>
              <h1
                style={{
                  fontSize: "2.25rem",
                  fontWeight: 800,
                  background:
                    "linear-gradient(to right, #fde047, #f9a8d4, #c084fc)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                }}
              >
                Happy Birthday Trishuu! 🎂
              </h1>
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  gap: "0.5rem",
                  marginTop: "0.5rem",
                }}
              >
                <Star style={{ color: "#fde047" }} size={24} />
                <Star style={{ color: "#f9a8d4" }} size={24} />
                <Star style={{ color: "#c084fc" }} size={24} />
              </div>
            </div>

            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "1rem",
                textAlign: "left",
                backgroundColor: "rgba(0,0,0,0.3)",
                padding: "1rem",
                borderRadius: "0.75rem",
                border: "1px solid rgba(250,204,21,0.3)",
              }}
            >
              <p
                style={{
                  color: "#fbcfe8",
                  lineHeight: "1.625",
                  fontSize: "1rem",
                  fontWeight: 500,
                }}
              >
                Every day with you feels like a small celebration 🥳🥂, but
                today the world feels extra lucky because you were born 🐣..
                Thank you for filling my life with warmth 🤗, laughter 😄, and a
                love that feels safe and magical at the same time 💚... I admire
                your heart, your strength, and the way you make even ordinary
                moments beautiful ✨..
              </p>

              <hr style={{ borderColor: "rgba(234,179,8,0.5)" }} />

              <p
                style={{
                  color: "white",
                  lineHeight: "1.625",
                  fontSize: "1.125rem",
                  fontWeight: 500,
                }}
              >
                Bhagwaan ji 🙇‍♂️, Meli Bacchi ka haath hamesha thame rakhna 🤞...
                Jab bhi vah ladkhadaye, Jab bhi vah dagmagaye... Life ke har
                mushkil pagdandiyon par saath dena... Itni shkti dijiyega ki Har
                sthiti me lavo pe muskan bani rahe, Hamesha Mushkurate rahe....
                😄😄
              </p>
            </div>

            <div style={{ position: "relative", marginTop: "1rem" }}>
              <img
                src={ASSETS.birthdayCake}
                alt="Birthday Cake"
                style={{
                  width: "100%",
                  height: "8rem",
                  objectFit: "cover",
                  borderRadius: "0.75rem",
                  opacity: 0.8,
                }}
              />
            </div>

            <div
              style={{
                display: "flex",
                justifyContent: "center",
                marginTop: "1.5rem",
                paddingTop: "1rem",
              }}
            >
              <button
                onClick={nextCard}
                style={{
                  background: "linear-gradient(to right, #facc15, #ec4899)",
                  color: "white",
                  padding: "1rem",
                  borderRadius: "9999px",
                  boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                <ArrowRight size={32} />
              </button>
            </div>
          </div>
        );

      case 31:
        return (
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              height: "100%",
            }}
          >
            <h1
              style={{
                fontSize: "2.25rem",
                fontWeight: 800,
                color: "white",
                marginBottom: "1.5rem",
              }}
            >
              🤗
            </h1>
            <img
              src={ASSETS.finalHug}
              alt="Big Hug"
              style={{
                width: "100%",
                height: "100%",
                maxHeight: "60vh",
                objectFit: "cover",
                borderRadius: "1rem",
                boxShadow: "0 0 40px rgba(236,72,153,0.5)",
                border: "4px solid rgba(255,255,255,0.2)",
              }}
            />
            <p
              style={{
                marginTop: "1rem",
                color: "#fbcfe8",
                fontSize: "1.25rem",
                fontWeight: "bold",
              }}
            >
              If I could, I'd pause time forever !
            </p>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background:
          "linear-gradient(to bottom right, #0f172a, #1e1b4b, #0f172a)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "1rem",
        position: "relative",
        overflow: "hidden",
        fontFamily: "Nunito, sans-serif",
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap');
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.3); border-radius: 4px; }
        
        @keyframes twinkle {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.2); }
        }

        @keyframes floatUp {
            0% { transform: translateY(0) scale(1); opacity: 0; }
            10% { opacity: 0.8; }
            90% { opacity: 0.8; }
            100% { transform: translateY(-100vh) scale(1); opacity: 0; }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        .animate-fadeIn { animation: fadeIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        button { transition: all 0.2s; }
        button:hover { transform: translateY(-2px); }
      `}</style>

      <BackgroundEffects />

      <div
        style={{
          position: "absolute",
          top: "2.5rem",
          right: "2.5rem",
          color: "rgba(254,249,195,0.3)",
          zIndex: 0,
        }}
      >
        <Moon size={80} />
      </div>

      <button
        onClick={toggleMusic}
        style={{
          position: "fixed",
          top: "1rem",
          right: "1rem",
          zIndex: 40,
          backgroundColor: "rgba(255,255,255,0.1)",
          backdropFilter: "blur(4px)",
          padding: "0.75rem",
          borderRadius: "9999px",
          color: "#f9a8d4",
          border: "1px solid rgba(255,255,255,0.2)",
          cursor: "pointer",
        }}
      >
        {isPlaying ? <Volume2 size={24} /> : <VolumeX size={24} />}
      </button>

      {isPlaying && (
        <div
          style={{
            position: "fixed",
            top: "-100%",
            opacity: 0,
            pointerEvents: "none",
          }}
        >
          <iframe
            width="1"
            height="1"
            src={`https://www.youtube.com/embed/${YOUTUBE_VIDEO_ID}?autoplay=1&loop=1&playlist=${YOUTUBE_VIDEO_ID}&controls=0`}
            title="YouTube video player"
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>
      )}

      <div
        style={{
          position: "relative",
          zIndex: 10,
          width: "100%",
          maxWidth: "28rem",
          backgroundColor: "rgba(15,23,42,0.6)",
          backdropFilter: "blur(12px)",
          border: "1px solid rgba(255,255,255,0.1)",
          boxShadow: "0 0 50px rgba(0,0,0,0.5)",
          borderRadius: "1.5rem",
          overflow: "hidden",
          minHeight: "550px",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <div
          style={{
            height: "0.375rem",
            backgroundColor: "rgba(255,255,255,0.05)",
            width: "100%",
          }}
        >
          <div
            style={{
              height: "100%",
              background: "linear-gradient(to right, #ec4899, #a855f7)",
              transition: "width 0.5s",
              boxShadow: "0 0 10px rgba(236,72,153,0.7)",
              width: `${(currentCard / 31) * 100}%`,
            }}
          ></div>
        </div>

        <div
          style={{
            padding: "2rem",
            flexGrow: 1,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            textAlign: "center",
          }}
        >
          {renderCardContent()}
        </div>

        <div
          style={{
            padding: "1rem",
            display: "flex",
            justifyContent: "space-between",
            color: "rgba(255,255,255,0.1)",
          }}
        >
          <Star size={16} />
          <Heart
            size={16}
            fill="currentColor"
            style={{ color: "rgba(236,72,153,0.1)" }}
          />
          <Star size={16} />
        </div>
      </div>

      <Modal
        isOpen={modal.show}
        onClose={closeModal}
        message={modal.message}
        gif={modal.gif}
      />
    </div>
  );
}

const KissCard = ({ title, gif, onNext }) => (
  <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
    <h2 style={{ fontSize: "1.875rem", color: "white", fontWeight: 800 }}>
      {title}
    </h2>
    <div
      style={{
        position: "relative",
        borderRadius: "0.75rem",
        overflow: "hidden",
        border: "4px solid rgba(236,72,153,0.3)",
        boxShadow: "0 0 30px rgba(236,72,153,0.3)",
      }}
    >
      <img
        src={gif}
        alt={title}
        style={{
          width: "100%",
          height: "16rem",
          objectFit: "cover",
        }}
      />
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "linear-gradient(to top, rgba(15,23,42,0.6), transparent)",
        }}
      ></div>
    </div>
    <div
      style={{ display: "flex", justifyContent: "center", marginTop: "2rem" }}
    >
      <button
        onClick={onNext}
        style={{
          background: "#ec4899",
          padding: "1rem",
          borderRadius: "9999px",
          color: "white",
          boxShadow: "0 10px 15px -3px rgba(0,0,0,0.1)",
          border: "none",
          cursor: "pointer",
        }}
      >
        <ArrowRight size={32} />
      </button>
    </div>
  </div>
);
